import { Container,Col,Row } from "react-bootstrap"

const Home=()=>{
    return(
        <Container fluid>
            <Row>
                <Col>
                    <h1>Home Page</h1>
                </Col>
            </Row>
        </Container>
    )
}
export default Home;