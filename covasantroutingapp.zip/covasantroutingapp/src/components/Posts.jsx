import { useEffect, useState } from "react";
import { Container, Col, Row, ListGroup } from "react-bootstrap"
import { getPosts } from "../services/postService";
import { Link, Outlet } from "react-router-dom";

const Posts = () => {
    const [posts, setPosts] = useState([]);
    const fetchPosts = async () => {
        let res = await getPosts();
        setPosts(await res.data);
    }
    useEffect(() => fetchPosts, []);
    return (
        <Container fluid>
            <Row>
                <Col>
                    <h1>Posts Page</h1>
                </Col>
            </Row>
            <Row>
                <Col>
                    <ListGroup>
                        {posts.map(post => (
                            <ListGroup.Item as={Link} key={post.id} to={`/posts/${post.id}`}>{post.id}</ListGroup.Item>
                        ))}
                    </ListGroup>

                </Col>
                <Col>
                    <Outlet />
                </Col>
            </Row>
        </Container>
    )
}
export default Posts;