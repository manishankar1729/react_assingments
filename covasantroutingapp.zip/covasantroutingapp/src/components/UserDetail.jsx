import { Container, Col, Row, Table } from "react-bootstrap"
import { useParams } from "react-router-dom";
import { getUser } from "../services/userServices";
import { useEffect,useState } from "react";

const UserDetail = () => {
    const { id } = useParams();
    const [user, setUser] = useState({});
     const fetchUserData=async(id,setUser)=>{
            try{
                const res=await getUser(id);
                setUser(res.data);
            }catch(error){
                console.error("Error fetching user:",error);
            }
        };
        useEffect(()=>{if(id){
            fetchUserData(id,setUser);
        }},[id]);
        return(
        <Container fluid>
            <Row>
                <Col>
                    <h1>UserDetail Page {id}</h1>
                </Col>
            </Row>
            <Row>
                <Col>
                    <Table>
                        <tbody>
                            {Object.keys(user).map((prop, index) => (
                                <tr key={index}>
                                    <td>{prop}</td>
                                    <td>{user[prop]}</td>

                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </Col>
            </Row>
        </Container>
    )
    
}
export default UserDetail;