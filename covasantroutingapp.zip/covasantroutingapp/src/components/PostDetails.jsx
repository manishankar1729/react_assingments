import { useEffect, useState } from "react";
import { Container,Col,Row, CardBody,Card} from "react-bootstrap"
import { useParams } from "react-router-dom";
import { getPost } from "../services/postService";

const PostDetail=()=>{
    const {id}=useParams();
    const[post,setPost]=useState({});
    const fetchPost=async(id,setPost)=>{
        try{
            const res=await getPost(id);
            setPost(res.data);
        }catch(error){
            console.error("Error fetching post:",error);
        }
    };
    useEffect(()=>{if(id){
        fetchPost(id,setPost);
    }},[id]);
    return(
        <Container fluid>
            <Row>
                <Col>
                    <h1>PostDetail Page {id}</h1>
                </Col>
            </Row>
            <Col>
            <Card style={{width:"18rem"}}>
                <Card.Body>
                    <Card.Title>{post.id}</Card.Title>
                    <Card.Text>{post.title}</Card.Text>
                    <Card.Text>{post.author}</Card.Text>
                </Card.Body>
            </Card>
            </Col>
        </Container>
    )
}
export default PostDetail;