import { Container, Col, Row, ListGroup } from "react-bootstrap"
import { Link, Routes,Route } from "react-router-dom";
import UserDetail from "./UserDetail";
import { useEffect,useState } from "react";
import {getUsers} from "../services/userServices";
const Users = () => {
    const[users,setUsers]=useState([]);

    const fetchUsers = async() => {
        let response=await getUsers();
        setUsers(await response.data);
    }
    useEffect(()=> fetchUsers,[]);
    return (
        <Container fluid>
            <Row>
                <Col>
                    <h1>Users Page</h1>
                    <Row>
                        <Col>
                            <ListGroup>
                                {users.map((user) => (
                                    <ListGroup.Item as={Link} key={user.id} to={`../users/${user.id}`}>{user.userName}</ListGroup.Item>
                                ))}
                            </ListGroup>
                        </Col>
                        <Col>
                        <Routes>
                            <Route path=":id" element={<UserDetail />} />
                        </Routes>
                        </Col>
                    </Row>
                </Col>
            </Row>
        </Container>
    )
}
export default Users;