import { Container,Col,Row } from "react-bootstrap"
import { Link } from "react-router-dom";

const Contact=()=>{
    return(
        <Container fluid>
            <Row>
                <Col>
                    <h1>Contact Page</h1>
                    <p>
                        <Link to ={"/contact/detail"}>
                        detail
                        </Link>
                    </p>
                </Col>
            </Row>
        </Container>
    )
}
export default Contact;