import { Container,Col,Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom"

const Detail=()=>{
    const navigate=useNavigate();
    return(
        <Container fluid>
            <Row>
                <Col>
                <h1>
                    Detail Page
                </h1>
                <button onClick={()=>navigate("../contact")}>Go Back</button>
                </Col>
            </Row>
        </Container>
    )
}
export default Detail;