import { Container,Col,Row } from "react-bootstrap"

const NotFound=()=>{
    return(
        <Container fluid>
            <Row>
                <Col>
                    <h1 style={{"color":"red"}}>NotFound Page</h1>
                </Col>
            </Row>
        </Container>
    )
}
export default NotFound;