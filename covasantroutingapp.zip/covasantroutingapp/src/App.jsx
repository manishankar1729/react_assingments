import { Col, Container, Row, Navbar, Nav } from "react-bootstrap";
import { Link, Route, Routes } from "react-router-dom";
import Home from "./components/Home";
import Users from "./components/Users";
import Posts from "./components/Posts";
import Contact from "./components/Contact";
import NotFound from "./components/NotFound";
import UserDetail from "./components/UserDetail";
import PostDetail from "./components/PostDetails";
import Detail from "./components/DetailComponents";

const App = () => {
  return (
    <Container fluid>
      <Row as="header">
        <Col>
          <h1>Sample Routing App</h1>
        </Col>
      </Row>
      <Navbar bg="dark" data-bs-theme="dark" className="row">
        <Container fluid>
          <Navbar.Brand as={Link} to={"/"}>Home</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link as={Link} to={"/posts"}>Posts</Nav.Link>
            <Nav.Link as={Link} to={"/users"}>Users </Nav.Link>
            <Nav.Link as={Link} to={"/contact"}>Contact </Nav.Link>
          </Nav>
        </Container>
      </Navbar>
      <Row>
        <Col>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/users/*" element={<Users />} />
            <Route path="/posts" element={<Posts />} >
              <Route path="/posts/:id" element={<PostDetail />} />
            </Route>
            <Route path="/contact" element={<Contact />} />
            <Route path="/contact/detail" element={<Detail/>}/>
            <Route path="*" element={<NotFound />} />


          </Routes>
        </Col>
      </Row>
    </Container>


  )
}
export default App;