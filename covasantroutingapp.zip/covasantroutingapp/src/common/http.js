import axios from 'axios';
import { baseUrl } from '../utilities/constants';

const http=axios.create({
    baseURL:baseUrl,
});
export default http;