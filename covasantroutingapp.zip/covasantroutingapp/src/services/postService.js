import http from "../common/http";

export const getPosts=()=> http.get("/posts");
export const getPost=id=> http.get(`/posts/${id}`);